//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WordSimilarity.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WORDSIMILARITY_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_INPUT1                      1000
#define IDC_INPUT2                      1001
#define IDC_OUTPUT                      1002
#define IDC_SEMEME_DISTANCE             1003
#define IDC_SEMEME_SIMILARITY           1004
#define IDC_SEMEME_LOOKUP               1005
#define IDC_MEANING_LOOKUP              1006
#define IDC_SEMEME_LOOKUP2              1007
#define IDC_MEANING_LOOKUP2             1008
#define IDC_COPY_TO_INPUT1              1009
#define IDC_COPY_TO_INPUT2              1010
#define IDC_MEANING_SIMILARITY          1011
#define IDC_WORD_SIMILARITY             1012
#define IDC_MEANING_LOOKUP_IN_FILE      1013
#define IDC_WORD_SIMILARITY_IN_FILE     1014
#define IDC_INPUT_IN_FILE               1015
#define IDC_MEANING1                    1016
#define IDC_MEANING2                    1017
#define IDC_ALPHA                       1018
#define IDC_BETA1                       1019
#define IDC_BETA2                       1020
#define IDC_BETA3                       1021
#define IDC_BETA4                       1022
#define IDC_GAMA                        1023
#define IDC_DELTA                       1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
